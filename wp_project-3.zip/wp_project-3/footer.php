<!--slide-starts-->
<div class="slide">
		<div class="container">
			<div class="fle-xsel">
			<ul id="flexiselDemo3">

<?php
$slide = new WP_Query(array(

'post_type' =>'sl'

));
print_r($slider);





			while(have_posts()) : the_post();?> 
				<li>
					<a href="#">
						<div class="banner-1">
						<?php the_post_thumbnail();?> 
						</div>
					</a>
				</li>
				<?php  endwhile;?>
			</ul>
							
								
					<div class="clearfix"> </div>
			</div>
		</div>
	</div>	
	<!--slide-end-->
	<!--footer-starts-->
	<div class="footer">
		<div class="container">
			<div class="footer-text">
				<p><?php echo get_theme_mod('copyright_section');?> </p>
			</div>
		</div>
	</div>
	<!--footer-end-->

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<?php wp_footer()?>

</body>
</html>