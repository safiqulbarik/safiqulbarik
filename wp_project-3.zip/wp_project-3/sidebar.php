
				<div class="col-md-4 about-right heading">
					
				<?php if ( is_active_sidebar( 'msb_right_sidebar' ) ) { 
        dynamic_sidebar('msb_right_sidebar');
 } 
 ?>


				</div>