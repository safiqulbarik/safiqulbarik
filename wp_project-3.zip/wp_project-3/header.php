<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset="<?php bloginfo('charset')?>" />

<?php wp_head()?>
</head>