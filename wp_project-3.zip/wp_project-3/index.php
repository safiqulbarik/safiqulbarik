<?php
get_header();

?>
<body <?php body_class()?> >
	<!--header-top-starts-->
	<div class="header-top">
		<div class="container">
			<div class="head-main">
				<a href="index.html">
					
				
				<?php the_custom_logo();?>			
			
			</a>
			</div>
		</div>
	</div>
	<!--header-top-end-->
	<!--start-header-->
	<div class="header">
			

	<div class="container">


	<ul class="navbar-nav menu">

					<?php 
					wp_nav_menu( array(
				  'theme_location'=>'primary',
					// 'fallback_cb' => false
					'depth'           => 3, // 1 = no dropdowns, 2 = with dropdowns.
					
					
					))
					
					
					;
					?>
</ul>

		
	</div>
</nav>

</div>



<div class="container style="color:blue;"">


		


			<div class="header-right">
				<div class="search-bar">
				<?php  get_search_form();?> 
			</div>
				<ul>
					<?php if(get_theme_mod('id_fb_section')) :?>

					<li><a href="<?php echo esc_url(get_theme_mod('id_fb_section'))?>"><span class="fb"> </span></a></li>
					
				<?php endif ?>


				<?php if(get_theme_mod('id_tw_section')) :?>
					<li><a href="<?php echo esc_url(get_theme_mod('id_tw_section'))?>"><span class="twit"> </span></a></li>
					<?php endif ?>
					
					<!-- <li><a href="#"><span class="pin"> </span></a></li>
					<li><a href="#"><span class="rss"> </span></a></li>
					<li><a href="#"><span class="drbl"> </span></a></li> -->
				</ul>
			</div>
				<div class="clearfix"></div>
			</div>
			</div>
		</div>	
	<!-- script-for-menu -->
	<!-- script-for-menu -->
		<script>
			$("span.menu").click(function(){
				$(" ul.navig").slideToggle("slow" , function(){
				});
			});
		</script>
	<!-- script-for-menu -->
	<!--banner-starts-->
	<div class="banner">
		<div class="container">
			<div class="banner-top" style="background-image: url('<?php echo header_image();?>')">
				<div class="banner-text" style="background-color:<?php echo get_theme_mod('id_text_bg_color')?>">
					<h1><?php echo get_theme_mod('id_header_text')?> </h1>
				</div>
			</div>
		</div>
	</div>
	<!--banner-end-->
	<!--about-starts-->
	<div class="about">
		<div class="container">
			<div class="about-main">
				<div class="col-md-8 about-left">
					<div class="about-tre">
					<?php while(have_posts()) : the_post();?> 

							<div class="col-md-6 abt-left">
								<a href="single.html" class="coffe-post-image"><?php the_post_thumbnail();?> </a>
								<h6><?php the_category(' ');?></h6>
								<h3><a href="single.html"><?php the_title();?></a></h3>
								<p><?php echo wp_trim_words(get_the_content(),30,'....' )?></p>
								<label><?php echo the_time('d M Y')?></label>
							</div>
							
						
						<?php  endwhile;?>
							
							<!-- <div class="clearfix"></div> -->
						
					</div>	
				</div>
				<?php get_sidebar()?>

				
				<div class="clearfix"></div>			
			</div>		
		</div>
	</div>

	
	<!--about-end-->
	<?php
	get_footer();
	?>